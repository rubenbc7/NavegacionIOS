//
//  ViewController.swift
//  Navegacion
//
//  Created by Alumno on 29/09/21.
//  Copyright © 2021 Ruben Borbolla. All rights reserved.
//

import UIKit

class AzulController: UIViewController {
    
    var nombre = ""
    var matricula = ""
    var promedio = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func doTapRuben(_ sender: Any) {
        nombre = "Ruben"
        matricula = "189216"
        promedio = "9.4"
        self.performSegue(withIdentifier: "goToAmarillo", sender: self)
    }
    @IBAction func doTapGabriel(_ sender: Any) {
        nombre = "Gabriel"
        matricula = "218303"
        promedio = "9.1"
        self.performSegue(withIdentifier: "goToAmarillo", sender: self)
    }
    @IBAction func doTapJose(_ sender: Any) {
        nombre = "Jose"
        matricula = "850708"
        promedio = "10"
        self.performSegue(withIdentifier: "goToAmarillo", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! AmarilloController
        destino.nombre = nombre
        destino.matricula = matricula
        destino.promedio = promedio
        
    }

}

